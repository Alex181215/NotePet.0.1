package com.example.recycler3;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import com.example.recycler3.databinding.ActivityCreateBinding;

import android.app.AlertDialog;
import android.app.Fragment;
import android.app.LauncherActivity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.zip.Inflater;

public class Create extends AppCompatActivity implements SampleCallback{
    private ActivityCreateBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCreateBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);
        setupMenu();
    }

    private void setupMenu() {
        Bundle argument = getIntent().getExtras();
        if (argument != null) {
            if (argument.getString("key").equals("pets")) {
                FragmentPets pets = new FragmentPets();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.container, pets);
                transaction.commit();
                headerShow("Мои питомцы");
                iconPetsOn();
            } else if (!argument.getString("key").equals("")) {
                Bundle bundle = new Bundle();
                String myMessage = argument.getString("key");
                bundle.putString("key", myMessage);
                FragmentEdit edit = new FragmentEdit();
                edit.setArguments(bundle);
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.container, edit);
                transaction.commit();
                headerShow("Редактирование");
                iconPetsOn();
            }
        } else {
            FragmentCreate create = new FragmentCreate();
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.container, create);
            transaction.commit();
            headerShow("Добавить питомца");
            iconPetsOn();
        }
    }

    // кнопка настройки на глайном экране
    public void setting(View view) {
        Log.d("TagCreate", "setting");
    }

    // Кнопка Меню на главном экране для Перехода в попап Меню
    public void menu(View view) {
        Log.d("TagCreate", "menu");
    }

    // метод отображения заголовка в зависимости от Фрагмента
    public void headerShow(String text) {
        binding.txHeader.setText(text);
    }

    private void iconMenuOn() {
        imageBarHide(binding.imageMenuRed, binding.imagePet, binding.imageNotes, binding.imageMenu, binding.imagePet, binding.imageNotes);
        Log.d("TagCreate", "iconMenuOn");
    }

    private void iconPetsOn() {
        imageBarHide(binding.imageMenu, binding.imagePetRed, binding.imageNotes, binding.imageMenuRed, binding.imagePet, binding.imageNotesRed);
        Log.d("TagCreate", "iconPetsOn");
    }

    private void iconNoteOn() {
        imageBarHide(binding.imageMenu, binding.imagePet, binding.imageNotesRed, binding.imageMenuRed, binding.imagePetRed, binding.imageNotes);
        Log.d("TagCreate", "iconNoteOn");
    }

    // метод отображения нижнего бара в зависимости от Фрагмента
    public void imageBarHide(ImageView visi1, ImageView visi2, ImageView visi3, ImageView gone1, ImageView gone2, ImageView gone3) {
        visi1.setVisibility(View.VISIBLE);
        visi2.setVisibility(View.VISIBLE);
        visi3.setVisibility(View.VISIBLE);
        gone1.setVisibility(View.GONE);
        gone2.setVisibility(View.GONE);
        gone3.setVisibility(View.GONE);
    }

    // Кнопка бара Питомцы на главном Экране для перехода в Мои питомцы
    public void pets(View view) {
        Log.d("TagCreate", "ButtonPets");
        FragmentPets pets = new FragmentPets();
        FragmentTransaction trans = getSupportFragmentManager().beginTransaction();
        trans.replace(R.id.container, pets);
        trans.commit();
        Log.d("TagCreate", "FragmentPets");
        headerShow("Мои питомцы");
        Log.d("TagCreate", "Мои питомцы");
        iconPetsOn();
    }

    // Кнопка Редактирование на Экране Мои питомцы, для его редактирования
    public void edit(View view) {
        Log.d("TagCreate", "ButtonEdit");
        FragmentEdit edit = new FragmentEdit();
        FragmentTransaction trans = getSupportFragmentManager().beginTransaction();
        trans.replace(R.id.container, edit);
        trans.commit();
        Log.d("TagCreate", "FragmentEdit");
        headerShow("Редактирование");
        Log.d("TagCreate", "Редактирование");
        iconPetsOn();
    }

    // Кнопка Добавить питомца на экране Мои питомцы для его добавления
    public void create(View view) {
        Log.d("TagCreate", "ButtonCreate");
        FragmentCreate create = new FragmentCreate();
        FragmentTransaction trans = getSupportFragmentManager().beginTransaction();
        trans.replace(R.id.container, create);
        trans.commit();
        Log.d("TagCreate", "FragmentCreate");
        headerShow("Добавить питомца");
        Log.d("TagCreate", "Добавить питомца");
        iconPetsOn();
    }

    // Кнопка История на экране Профиль для перехода в Историю изменения параметров
    public void history(View view) {
        Log.d("TagCreate", "ButtonHistory");
        FragmentHistory history = new FragmentHistory();
        FragmentTransaction trans = getSupportFragmentManager().beginTransaction();
        trans.replace(R.id.container, history);
        trans.commit();
        Log.d("TagCreate", "FragmentHistory");
        headerShow("История");
        Log.d("TagCreate", "История");
        iconPetsOn();
    }

    // Кнопка бара Заметки на главном экране для перехода на экран Заметки
    public void note(View view) {
        Log.d("TagCreate", "ButtonNote");
        FragmentNote note = new FragmentNote();
        FragmentTransaction trans = getSupportFragmentManager().beginTransaction();
        trans.replace(R.id.container, note);
        trans.commit();
        Log.d("TagCreate", "FragmentNote");
        headerShow("Заметки");
        Log.d("TagCreate", "Заметки");
        iconNoteOn();
    }

    // Cпрятать клавиатуру при нажатии на экран
    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        View v = getCurrentFocus();
        boolean ret = super.dispatchTouchEvent(event);
        Log.d("TagCreate", "Касание экрана");
        if (v instanceof EditText) {
            View w = getCurrentFocus();
            int scrcoords[] = new int[2];
            w.getLocationOnScreen(scrcoords);
            float x = event.getRawX() + w.getLeft() - scrcoords[0];
            float y = event.getRawY() + w.getTop() - scrcoords[1];

            Log.d("Activity", "Touch event " + event.getRawX() + "," + event.getRawY() + " " + x + "," + y + " rect " + w.getLeft() + "," + w.getTop() + "," + w.getRight() + "," + w.getBottom() + " coords " + scrcoords[0] + "," + scrcoords[1]);
            if (event.getAction() == MotionEvent.ACTION_UP && (x < w.getLeft() || x >= w.getRight() || y < w.getTop() || y > w.getBottom())) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(getWindow().getCurrentFocus().getWindowToken(), 0);
            }
        }
        return ret;
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("TagCreate", "onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("TagCreate", "onPause");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("TagCreate", "onDestroy");

    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("TagCreate", "onStop");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("TagCreate", "onStart");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("TagCreate", "onRestart");
    }

    @Override
    public void onButtonClicked(String position) {
        Toast.makeText(this, "Получилось", Toast.LENGTH_SHORT).show();
        Toast.makeText(this, position, Toast.LENGTH_SHORT).show();

        Bundle bundle = new Bundle();
//        String myMessage = argument.getString("key");
        bundle.putString("key", position);
        FragmentEdit edit = new FragmentEdit();
        edit.setArguments(bundle);
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.container, edit);
        transaction.commit();
        headerShow("Редактирование");
        iconPetsOn();
    }
}
