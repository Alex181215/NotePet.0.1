package com.example.recycler3;

import static android.app.Activity.RESULT_OK;
import static android.content.Context.MODE_PRIVATE;
import static android.view.View.GONE;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.recycler3.databinding.FragmentCreateBinding;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class FragmentCreate extends Fragment {
    CreateMetod createMetod = new CreateMetod();

    private static final int GALLERY_REQUEST = 1;


    String animalText;
    private FragmentCreate context = this;

    private ArrayList<String> animalArrayList = new ArrayList<String>();
    private ArrayAdapter<String> animalArrayAdapter;

    private String gender = "";
    private FragmentCreateBinding binding;

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentCreateBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();

        jump(); // метод перехода по датам
        editTextHide(); // методы спрятать фокус
        hideParam(); // метод скрыть параметры по умолчанию
        hideInfo(); // метод скрыть информацию по умолчанию
        listener(); // слушатели кнопок спойлеров, скрыть и показать по нажатию
        spAnimal(); // метод спинера, выпадающего списка, выбор вида питомца
        rgGender(); // метод радиокнопки, выбор пола
        ava(); // слушатели кнопки добавить аву
        saveM(); // слушатели для кнопки сохранить
        return view;
    }

    public void save(){

        if (binding.edTextName.getText().toString().equals("")) {
            Toast.makeText(getActivity(), "Введите имя Питомца", Toast.LENGTH_SHORT).show();
            binding.edTextName.requestFocus();
            setSoftKeyboard();
        } else if (binding.edTextDay.getText().toString().equals("")) {
            Toast.makeText(getActivity(), "Введите день рождения", Toast.LENGTH_SHORT).show();
            binding.edTextDay.requestFocus();
            setSoftKeyboard();
        } else if (binding.edTextMount.getText().toString().equals("")) {
            Toast.makeText(getActivity(), "Введите месяц рождения", Toast.LENGTH_SHORT).show();
            binding.edTextMount.requestFocus();
            setSoftKeyboard();
        } else if (binding.edTextAge.getText().toString().equals("")) {
            Toast.makeText(getActivity(), "Введите год рождения", Toast.LENGTH_SHORT).show();
            binding.edTextAge.requestFocus();
            setSoftKeyboard();
        } else if (binding.spinnerAnimal.getSelectedItem().toString().equals("Выбрать")) {
            Toast.makeText(getActivity(), "Выберите вид Питомца", Toast.LENGTH_SHORT).show();
            binding.spinnerAnimal.requestFocus();
            binding.spinnerAnimal.performClick();
        } else {
            testData(binding.edTextDay, binding.edTextMount, binding.edTextDay);
        }
    }

    private void testData(EditText day, EditText mount, EditText age) {
        SimpleDateFormat datD = new SimpleDateFormat("dd");
        String currentDateandD = datD.format(new Date());
        String data1 = ("" + currentDateandD);
        int currentDay = Integer.parseInt(data1);

        SimpleDateFormat datM = new SimpleDateFormat("MM");
        String currentDateandM = datM.format(new Date());
        String data2 = ("" + currentDateandM);
        int currentMount = Integer.parseInt(data2);

        SimpleDateFormat datY = new SimpleDateFormat("yyyy");
        String currentDateandY = datY.format(new Date());
        String data3 = ("" + currentDateandY);
        int currentAge = Integer.parseInt(data3);

        if (!day.getText().toString().equals("") && !mount.getText().toString().equals("") && !age.getText().toString().equals("")) {
            int dayHappy = Integer.parseInt(day.getText().toString());
            int mountHappy = Integer.parseInt(mount.getText().toString());
            int ageHappy = Integer.parseInt(age.getText().toString());
            if (dayHappy <= 0 || mountHappy <= 0 || ageHappy <= 0) {
                Toast.makeText(getActivity(), "Неверная дата", Toast.LENGTH_SHORT).show();
                day.setText("");
                mount.setText("");
                age.setText("");
                day.requestFocus();
            } else if (dayHappy > 31) {
                Toast.makeText(getActivity(), "Превышает количество дней в месяце", Toast.LENGTH_SHORT).show();
                day.setText("");
                day.requestFocus();
            } else if (dayHappy > currentDay && mountHappy == currentMount && ageHappy == currentAge) {
                Toast.makeText(getActivity(), "Превышает текущий день", Toast.LENGTH_SHORT).show();
                day.setText("");
                day.requestFocus();
            } else if (mountHappy > 12) {
                Toast.makeText(getActivity(), "Превышает количество месяцев в году", Toast.LENGTH_SHORT).show();
                mount.setText("");
                mount.requestFocus();
            } else if (dayHappy >= currentDay && mountHappy > currentMount && ageHappy == currentAge) {
                Toast.makeText(getActivity(), "Превышает текущий месяц", Toast.LENGTH_SHORT).show();
                mount.setText("");
                mount.requestFocus();
            } else if (dayHappy <= currentDay && mountHappy > currentMount && ageHappy == currentAge) {
                Toast.makeText(getActivity(), "Превышает текущий месяц", Toast.LENGTH_SHORT).show();
                mount.setText("");
                mount.requestFocus();
            } else if (ageHappy > currentAge) {
                Toast.makeText(getActivity(), "Превышает текущий год", Toast.LENGTH_SHORT).show();
                age.setText("");
                age.requestFocus();
            } else {
                savePet();
            }
        }
    }

    private void savePet() {
        for (int i = 1; i < 100; i++) {
            SharedPreferences sharedPreferences = getActivity().getSharedPreferences("prefName" + i, MODE_PRIVATE);
            if (sharedPreferences.getString("name" + i, "").equals("")) {
                saveStatus("prefMyStatus" + i, "myStatus" + i);
                saveData("prefData" + i, "data" + i);
                saveEditText("prefName" + i, "name" + i, binding.edTextName);
                saveEditText("prefDay" + i, "day" + i, binding.edTextDay);
                saveEditText("prefMount" + i, "mount" + i, binding.edTextMount);
                saveEditText("prefAge" + i, "age" + i, binding.edTextAge);
                saveGender("prefGender" + i, "gender" + i, gender);
                saveEditText("prefChip" + i, "chip" + i, binding.edTextChip);
                saveSpiner("prefAnimal"+i, "animal"+i, binding.spinnerAnimal);
                saveEditText("prefBreed"+i, "breed"+i, binding.edTextBreed);
                saveEditText("prefColor"+i, "color"+i, binding.edTextColor);
                saveEditText("prefWeight"+i, "weight"+i, binding.edTextWeight);
                saveSpiner("prefKg"+i, "kg"+i, binding.spinnerKg);
                saveEditText("prefHeight"+i, "height"+i,  binding.edTextHeight);
                saveEditText("prefBust"+i, "bust"+i,  binding.edTextBust);
                saveEditText("prefBack"+i, "back"+i,  binding.edTextBack);
                saveEditText("prefGroin"+i, "groin"+i,  binding.edTextGroin);
                saveEditText("prefVolume"+i, "volume"+i,  binding.edTextVolume);
                saveEditText("prefLength"+i, "length"+i,  binding.edTextLength);
                saveEditText("prefWidth"+i, "width"+i,  binding.edTextWidth);
                saveEditText("prefDayCast"+i, "dayCast"+i,  binding.edTextDayCast);
                saveEditText("prefMountCast"+i, "mountCast"+i, binding.edTextMountCast);
                saveEditText("prefAgeCast"+i, "ageCast"+i, binding.edTextAgeCast);
                saveEditText("prefDayCicle"+i, "dayCicle"+i, binding.edTextDayCicle);
                saveEditText("prefMountCicle"+i, "mountCicle"+i, binding.edTextMountCicle);
                saveEditText("prefAgeCicle"+i, "ageCicle"+i, binding.edTextAgeCicle);
                saveEditText("prefDayCicleExit"+i, "dayCicleExit"+i, binding.edTextDayCicle2);
                saveEditText("prefMountCicleExit"+i, "mountCicleExit"+i, binding.edTextMountCicle2);
                saveEditText("prefAgeCicleExit"+i, "ageCicleExit"+i, binding.edTextAgeCicle2);
                saveEditText("prefNursery"+i, "nursery"+i, binding.edTextNursery);
                saveEditText("prefNote"+i, "note"+i, binding.edTextNote);
                break;
            }
        }

        sendPet();
    }

    // метод для сохранения выбора спинера, выпающего списка ( вида животного )
    private void saveSpiner(String pref, String key, Spinner spinner) {
        if (!spinner.getSelectedItem().toString().equals("Выбрать")) {
            SharedPreferences Shared = getActivity().getSharedPreferences(pref, MODE_PRIVATE);
            SharedPreferences.Editor editor = Shared.edit();
            editor.putString(key, spinner.getSelectedItem().toString());
            editor.apply();
        }
    }

    // метод для сохранения выбора радиокнопки ( пола )
    private void saveGender(String pref, String key, String gender) {
        if (!gender.equals("")) {
            SharedPreferences Shared = getActivity().getSharedPreferences(pref, MODE_PRIVATE);
            SharedPreferences.Editor editor = Shared.edit();
            editor.putString(key, gender);
            editor.apply();
        }
    }

    private void saveData(String pref, String key) {
        String data = "";
        SimpleDateFormat dat = new SimpleDateFormat("dd.MM.yy");
        String currentDateand = dat.format(new Date());
        data = ("" + currentDateand);
        SharedPreferences Shared = getActivity().getSharedPreferences(pref, MODE_PRIVATE);
        SharedPreferences.Editor editor = Shared.edit();
        editor.putString(key, data);
        editor.apply();
    }

    // метод для сохранения остальных данных с форм заполнения пользователем
    private void saveStatus(String pref, String key) {
        SharedPreferences Shared = getActivity().getSharedPreferences(pref, MODE_PRIVATE);
        SharedPreferences.Editor editor = Shared.edit();
        editor.putString(key, "Актуальное");
        editor.apply();
    }

    // метод вызова Профиля
    private void sendPet() {
        FragmentPets pets = new FragmentPets();
        FragmentTransaction trans = getActivity().getSupportFragmentManager().beginTransaction();
        trans.replace(R.id.container, pets);
        trans.commit();
    }



    // метод для сохранения остальных данных с форм заполнения пользователем
    private void saveEditText(String pref, String key, EditText editText) {
        if (!editText.getText().toString().equals("")) {
            SharedPreferences Shared = getActivity().getSharedPreferences(pref, MODE_PRIVATE);
            SharedPreferences.Editor editor = Shared.edit();
            editor.putString(key, editText.getText().toString());
            editor.apply();
        }

    }


    // метод для захвата и подмены изображения из галереи
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent) {
        super.onActivityResult(requestCode, resultCode, imageReturnedIntent);
        binding.image.setVisibility(GONE);
        binding.ava.setVisibility(View.VISIBLE);
        Bitmap bitmap = null;
        switch (requestCode) {
            case GALLERY_REQUEST:
                if (resultCode == RESULT_OK) {
                    Uri selectedImage = imageReturnedIntent.getData();
                    try {
                        bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), selectedImage);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    binding.ava2.setImageBitmap(bitmap);
                    try {
                        saveToInternalStorage(bitmap);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
        }
    }

    // метод для сохранеия изображения в локальную память
    private String saveToInternalStorage(Bitmap bitmapImage) throws IOException {
        ContextWrapper cw = new ContextWrapper(getActivity().getApplicationContext());
        // путь /data/data/yourapp/app_data/imageDir
        File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
        // Создаем imageDir
        File mypath = new File(directory, "profile.jpg");

        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(mypath);
            // Используем метод сжатия BitMap объекта для записи в OutputStream
            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            fos.close();
        }
        return directory.getAbsolutePath();
    }

    private void ava() {
        // кнопка загрузить аватарку
        binding.image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                photoPickerIntent.setType("image/*");
                startActivityForResult(photoPickerIntent, GALLERY_REQUEST);
            }
        });

        // кнопка загрузить аватарку
        binding.ava2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                photoPickerIntent.setType("image/*");
                startActivityForResult(photoPickerIntent, GALLERY_REQUEST);
            }
        });

    }

    private void spAnimal() {
        animalArrayList.add("Выбрать");
        animalArrayList.add("Собака");
        animalArrayList.add("Кошка");
        animalArrayList.add("Попугай");
        animalArrayList.add("Крыса");
        animalArrayList.add("Шиншила");
        animalArrayList.add("Хомяк");
        animalArrayList.add("Черепаха");
        loadSpAnimal();
        animalArrayList.add("Другое");
        animalArrayAdapter = new ArrayAdapter<String>(getActivity(), R.layout.spinner_layout, R.id.text_item, animalArrayList);
        binding.spinnerAnimal.setAdapter(animalArrayAdapter);
        binding.spinnerAnimal.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = parent.getItemAtPosition(position).toString();
                if (selectedItem.equals("Другое")) {
                    spinerAnimaltest();
                }
            }

            private void spinerAnimaltest() {
                LayoutInflater li = LayoutInflater.from(getActivity());
                View promptsView = li.inflate(R.layout.spinner_animal_layout, null);
                AlertDialog.Builder mDialogBuilder = new AlertDialog.Builder(getActivity());
                mDialogBuilder.setView(promptsView);
                final EditText userInput = (EditText) promptsView.findViewById(R.id.set_text);
                mDialogBuilder
                        .setCancelable(false)
                        .setPositiveButton("OK",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        animalText = userInput.getText().toString();
                                        saveMyAnimal();
                                        onAdd();
                                        int count = animalArrayList.size();
                                        binding.spinnerAnimal.setSelection(count - 1);
                                    }

                                    // метод сохранения новых видов питомцев
                                    public void saveMyAnimal() {
                                        for (int i = 1; i < 100; i++) {

                                            SharedPreferences sharedPreferences1 = getActivity().getSharedPreferences("prefMyAnimal" + i, MODE_PRIVATE);
                                            if (sharedPreferences1.getString("myAnimal" + i, "").equals("")) {
                                                SharedPreferences shared = getActivity().getSharedPreferences("prefMyAnimal" + i, MODE_PRIVATE);
                                                SharedPreferences.Editor editor = shared.edit();
                                                editor.putString("myAnimal" + i, animalText);
                                                editor.apply();
                                                break;
                                            }

                                        }
                                    }

                                    private void onAdd() {
                                        animalArrayList.add(animalText + "");
                                        binding.spinnerAnimal.setAdapter(animalArrayAdapter); // наполняем спиннер данными из адаптера
                                    }

                                })
                        .setNegativeButton("Отмена",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                    }
                                });
                AlertDialog alertDialog = mDialogBuilder.create();
                alertDialog.show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    // Метод проверки и добавление новых питомцев из сохраненки
    private void loadSpAnimal() {
        for (int i = 1; i < 100; i++) {
            SharedPreferences sharedPreferences = getActivity().getSharedPreferences("prefMyAnimal" + i, MODE_PRIVATE);
            if (!sharedPreferences.getString("myAnimal" + i, "").equals("")) {
                animalArrayList.add(sharedPreferences.getString("myAnimal" + i, ""));
            }
        }
    }


    private void rgGender() {
        // Слушатель выбора радиокнопки
        binding.radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case -1:
                        Toast.makeText(getActivity().getApplicationContext(), "Ничего не выбрано",
                                Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.radioButtonOne:
                        gender = "Мужской";
                        break;
                    case R.id.radioButtonTwo:
                        gender = "Женский";
                        break;
                    default:
                        break;
                }
            }
        });
    }


    private void jump() {
        // автоматический переход Дата рождения
        createMetod.dataAvtomat(binding.edTextDay, binding.edTextMount, binding.edTextAge, binding.edTextChip);

        // автоматический переход по параметрам
        createMetod.paramAvtomat(binding.edTextWeight, binding.edTextHeight, binding.edTextBust, binding.edTextBack, binding.edTextGroin, binding.edTextVolume, binding.edTextLength, binding.edTextWidth);

        // автоматический переход Дата кастрации
        createMetod.dataAvtomat(binding.edTextDayCast, binding.edTextMountCast, binding.edTextAgeCast, binding.edTextDayCicle);

        // автоматический переход Дата начало цикла
        createMetod.dataAvtomat(binding.edTextDayCicle, binding.edTextMountCicle, binding.edTextAgeCicle, binding.edTextDayCicle2);

        // аатоматический переход Дата конца цикла
        createMetod.dataAvtomat(binding.edTextDayCicle2, binding.edTextMountCicle2, binding.edTextAgeCicle2, binding.edTextNursery);
    }

    public void editTextHide() {
        enter(binding.edTextChip);
        enter(binding.edTextColor);
        enter(binding.edTextWidth);
    }

    // При нажатии на Enter на кливиатуре убираем фокус и прячем клавиатуру
    void enter(EditText editText) {
        editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    editText.clearFocus();
                    setSoftKeyboard();
                    return true;
                }
                return false;
            }
        });
    }

    private void setSoftKeyboard() {
        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Activity.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
    }

    public void listener() {
        binding.headerTextParams.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnParam();
            }
        });

        binding.btnShowParams.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnParam();
            }
        });

        binding.btnHideParams.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnParam();
            }
        });

        binding.headerTextInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnInfo();
            }
        });

        binding.btnShowInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnInfo();
            }
        });

        binding.btnHideInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnInfo();
            }
        });

    }

    // кнопка по нажатию на текст, скрыть или показать Параметры onClick
    public void btnParam() {
        if (binding.btnShowParams.getVisibility() == View.VISIBLE) {
            binding.btnShowParams.setVisibility(View.GONE);
            binding.btnHideParams.setVisibility(View.VISIBLE);
            showParams();
        } else {
            binding.btnShowParams.setVisibility(View.VISIBLE);
            binding.btnHideParams.setVisibility(View.GONE);
            hideParam();
        }
    }

    // метод скрыть параметры из класса Креат работат по умолчанию при загрузке
    private void hideParam() {
        createMetod.hideParam(binding.btnHideParams,
                binding.spinnerKg,
                binding.textWeight, binding.textHeight, binding.textBust, binding.textBack, binding.textGroin, binding.textGroin2, binding.textVolume, binding.textLength, binding.textWidth,
                binding.edTextWeight, binding.edTextHeight, binding.edTextBust, binding.edTextBack, binding.edTextGroin, binding.edTextVolume, binding.edTextLength, binding.edTextWidth,
                binding.smHeight, binding.smBust, binding.smBack, binding.smGroin, binding.smVolume, binding.smLength,binding.smWidth,
                binding.layoutWeightHeight, binding.layoutWeightHeightText, binding.layoutBustBack,
                binding.layoutBustBackText, binding.layoutNeckGroin, binding.layoutNeckGroinText, binding.layoutLengthWidth, binding.layoutLengthWidthText,
                binding.layoutWeight, binding.layoutHeight, binding.layoutBust, binding.layoutBack, binding.layoutGroin, binding.layoutVolume, binding.layoutLength, binding.layoutWidth);
    }

    // метод показать параметры
    private void showParams() {
        createMetod.showParam(binding.btnHideParams,
                binding.spinnerKg,
                binding.textWeight, binding.textHeight, binding.textBust, binding.textBack, binding.textGroin, binding.textGroin2, binding.textVolume, binding.textLength, binding.textWidth,
                binding.edTextWeight, binding.edTextHeight, binding.edTextBust, binding.edTextBack, binding.edTextGroin, binding.edTextVolume, binding.edTextLength, binding.edTextWidth,
                binding.smHeight, binding.smBust, binding.smBack, binding.smGroin, binding.smVolume, binding.smLength, binding.smWidth,
                binding.layoutDataGender, binding.layoutDataGenderText, binding.layoutWeightHeight, binding.layoutWeightHeightText, binding.layoutBustBack,
                binding.layoutBustBackText,binding.layoutNeckGroin, binding.layoutNeckGroinText, binding.layoutLengthWidth, binding.layoutLengthWidthText,
                binding.layoutWeight, binding.layoutHeight, binding.layoutBust, binding.layoutBack, binding.layoutGroin, binding.layoutVolume, binding.layoutLength, binding.layoutWidth);
    }

    // кнопка по нажатию на текст, скрыть или показать Иную информацию из onClick
    public void btnInfo() {
        if (binding.btnShowInfo.getVisibility() == View.VISIBLE) {
            binding.btnShowInfo.setVisibility(View.GONE);
            binding.btnHideInfo.setVisibility(View.VISIBLE);
            showInfo();
        } else {
            binding.btnShowInfo.setVisibility(View.VISIBLE);
            binding.btnHideInfo.setVisibility(View.GONE);
            hideInfo();
        }
    }

    // метод скрыть иную информацию из класса Креат работат по умолчанию при загрузке
    private void hideInfo() {
        createMetod.hideInfo(binding.btnHideInfo,
                binding.textCast, binding.textCicl, binding.textNursery, binding.textNote,
                binding.edTextDayCast, binding.edTextMountCast, binding.edTextAgeCast,
                binding.edTextDayCicle, binding.edTextMountCicle, binding.edTextAgeCicle,
                binding.edTextDayCicle2, binding.edTextMountCicle2, binding.edTextAgeCicle2,
                binding.edTextNursery, binding.edTextNote, binding.tochDayCast, binding.tochMountCast,
                binding.tochAgeCast, binding.tochDayCicle, binding.tochMountCicle,
                binding.tochAgeCicle, binding.tochDayCicle2, binding.tochMountCicle2, binding.tochAgeCicle2,
                binding.layoutDataCast, binding.layoutDataCicle, binding.layoutDataCicle2
        );
    }

    // Метод показать иную информацию
    private void showInfo() {
        createMetod.showInfo(binding.btnHideInfo,
                binding.textCast, binding.textCicl, binding.textNursery, binding.textNote,
                binding.edTextDayCast, binding.edTextMountCast, binding.edTextAgeCast,
                binding.edTextDayCicle, binding.edTextMountCicle, binding.edTextAgeCicle,
                binding.edTextDayCicle2, binding.edTextMountCicle2, binding.edTextAgeCicle2,
                binding.edTextNursery, binding.edTextNote, binding.tochDayCast, binding.tochMountCast,
                binding.tochAgeCast, binding.tochDayCicle, binding.tochMountCicle,
                binding.tochAgeCicle, binding.tochDayCicle2, binding.tochMountCicle2, binding.tochAgeCicle2,
                binding.layoutDataCast, binding.layoutDataCicle, binding.layoutDataCicle2);
    }

    public  void saveM(){
        binding.buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                save();
            }
        });
        binding.getpetmenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                save();
            }
        });

        binding.btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                save();
            }
        });
    }

}