package com.example.recycler3;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.recycler3.databinding.FragmentPetsBinding;

import java.util.ArrayList;
import java.util.List;

public class FragmentPets extends Fragment implements RecyclerViewClickInterface {
    AgeCalculator2 ageCalculator = new AgeCalculator2();
    private FragmentPetsBinding binding;
    private SampleCallback callback;

    RecyclerView recyclerView;
    RecyclerAdapter recyclerAdapter;
    List<String> nameList;
    List<String> ageList;
    SwipeRefreshLayout swipeRefreshLayout;

    View view;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof SampleCallback) {
            callback = (SampleCallback) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement SampleCallback");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        callback = null;
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentPetsBinding.inflate(getLayoutInflater());
        view = binding.getRoot();

        nameList = new ArrayList<>();
        ageList = new ArrayList<>();
        recyclerView = binding.recyclerView;
        recyclerAdapter = new RecyclerAdapter(nameList, ageList, this);
        recyclerView.setAdapter(recyclerAdapter);
        for (int i = 0; i < 100; i++) {
            SharedPreferences sharedPreferences = getActivity().getSharedPreferences("prefName" + i, Context.MODE_PRIVATE);
            SharedPreferences sharedPreferences2 = getActivity().getSharedPreferences("prefDay" + i, Context.MODE_PRIVATE);
            SharedPreferences sharedPreferences3 = getActivity().getSharedPreferences("prefMount" + i, Context.MODE_PRIVATE);
            SharedPreferences sharedPreferences4 = getActivity().getSharedPreferences("prefAge" + i, Context.MODE_PRIVATE);
            SharedPreferences sharedPreferences5 = getActivity().getSharedPreferences("prefAnimal" + i, Context.MODE_PRIVATE);
            String day = sharedPreferences2.getString("day" + i, "");
            String mount = sharedPreferences3.getString("mount" + i, "");
            String age = sharedPreferences4.getString("age" + i, "");
            String animal = sharedPreferences5.getString("animal" + i, "");
            if (!sharedPreferences.getString("name" + i, "").equals("")) {
                nameList.add(sharedPreferences.getString("name" + i, ""));
                ageCalculator.ageCalculator(day, mount, age, (ArrayList) ageList, animal);
            }
        }

        swipeRefreshLayout = binding.swipeRefreshLayout;
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                recyclerAdapter.notifyDataSetChanged();
                swipeRefreshLayout.setRefreshing(false);
            }
        });
        return view;
    }


    @Override
    public void onItemClick(int position) {
        Toast.makeText(getContext(), nameList.get(position), Toast.LENGTH_SHORT).show();
        // получаем индекс позиции, и сохраняем в переменную
        position = position + 1;
        callback.onButtonClicked(position+"");
    }
}