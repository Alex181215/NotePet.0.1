package com.example.recycler3;

public interface SampleCallback {
    void onButtonClicked(String position);
}
