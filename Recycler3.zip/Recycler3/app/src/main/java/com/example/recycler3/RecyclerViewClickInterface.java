package com.example.recycler3;

public interface RecyclerViewClickInterface {
    void onItemClick(int position);
}
