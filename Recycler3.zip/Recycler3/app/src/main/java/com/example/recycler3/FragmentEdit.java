package com.example.recycler3;

import static android.app.Activity.RESULT_OK;
import static android.content.Context.MODE_PRIVATE;
import static android.view.View.GONE;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.recycler3.databinding.FragmentEditBinding;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


public class FragmentEdit extends Fragment {
    CreateMetod createMetod = new CreateMetod();
    private static final int GALLERY_REQUEST = 1;

    String animalText;
    private FragmentEdit context = this;

    private ArrayList<String> animalArrayList = new ArrayList<String>();
    private ArrayAdapter<String> animalArrayAdapter;

    private String gender = "";

    int key = 0;

    private FragmentEditBinding binding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentEditBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();

        jump(); // метод перехода по датам
        editTextHide(); // методы спрятать фокус
        hideParam(); // метод скрыть параметры по умолчанию
        hideInfo(); // метод скрыть информацию по умолчанию
        listener(); // слушатели кнопок спойлеров, скрыть и показать по нажатию
        spAnimal(); // метод спинера, выпадающего списка, выбор вида питомца
        rgGender(); // метод радиокнопки, выбор пола
        set("prefName", "name", binding.edTextNameED);
        set("prefDay", "day", binding.edTextDay);
        set("prefMount", "mount", binding.edTextMount);
        set("prefAge", "age", binding.edTextAge);
        gender("prefGender", "gender", binding.radioButtonOne, binding.radioButtonTwo);
        set("prefChip", "chip", binding.edTextChip);
        animal("prefAnimal", "animal", binding.spinnerAnimal);
        set("prefBreed", "breed", binding.edTextBreed);
        set("prefColor", "color", binding.edTextColor);
        set("prefWeight", "weight", binding.edTextWeight);
        set("prefHeight", "height", binding.edTextHeight);
        set("prefBust", "bust", binding.edTextBust);
        set("prefBack", "back", binding.edTextBack);
        set("prefGroin", "groin", binding.edTextGroin);
        set("prefVolume", "volume", binding.edTextVolume);
        set("prefLength", "length", binding.edTextLength);
        set("prefWidth", "width", binding.edTextWidth);
        set("prefDayCast", "dayCast", binding.edTextDayCast);
        set("prefMountCast", "mountCast", binding.edTextMountCast);
        set("prefAgeCast", "ageCast", binding.edTextAgeCast);
        set("prefDayCicle", "dayCicle", binding.edTextDayCicle);
        set("prefMountCicle", "mountCicle", binding.edTextMountCicle);
        set("prefAgeCicle", "ageCicle", binding.edTextAgeCicle);
        set("prefDayCicleExit", "dayCicleExit", binding.edTextDayCicle2);
        set("prefMountCicleExit", "mountCicleExit", binding.edTextMountCicle2);
        set("prefAgeCicleExit", "ageCicleExit", binding.edTextAgeCicle2);
        set("prefNursery", "nursery", binding.edTextNursery);
        set("prefNote", "note", binding.edTextNote);

        ava(); // слушатели кнопки добавить аву
        saveM();
        return view;
    }

    private void animal(String pref, String key, Spinner spinner) {
        for (int i = 0; i < 100; i++) {
            if (this.getArguments().getString("key").equals(i+"")) {
                SharedPreferences sharedPreferences = getActivity().getSharedPreferences(pref + i, Context.MODE_PRIVATE);
                String testAnimal = sharedPreferences.getString(key + i, "");

                switch (testAnimal) {
                    case "Выбрать":
                        spinner.setSelection(0);
                        break;
                    case "Собака":
                        spinner.setSelection(1);
                        break;
                    case "Кошка":
                        spinner.setSelection(2);
                        break;
                    case "Попугай":
                        spinner.setSelection(3);
                        break;
                    case "Крыса":
                        spinner.setSelection(4);
                        break;
                    case "Шиншила":
                        spinner.setSelection(5);
                        break;
                    case "Хомяк":
                        spinner.setSelection(6);
                        break;
                    case "Черепаха":
                        spinner.setSelection(7);
                        break;
                }

                SharedPreferences shar = getActivity().getSharedPreferences(pref + i, MODE_PRIVATE);
                String tera = shar.getString(key + i, "");
                if (!tera.equals("Выбрать") && !tera.equals("Собака") && !tera.equals("Кошка") && !tera.equals("Попугай") && !tera.equals("Крыса") && !tera.equals("Шиншила") && !tera.equals("Хомяк") && !tera.equals("Черепаха")) {
                    for (int f = 1; f < 100; f++) {
                        SharedPreferences sharedPreferences1 = getActivity().getSharedPreferences("prefMyAnimal"+f , MODE_PRIVATE);
                        if (sharedPreferences1.getString("myAnimal" + f, "").equals(tera)) {
                            spinner.setSelection(7+f);
                        }
                    }
                }
            }
        }
    }

    // Метод заполнения сохраненки
    public void set(String pref, String  key, EditText text ){
        for (int i = 0; i < 100; i++) {
            if (this.getArguments().getString("key").equals(i+"")) {
                SharedPreferences sharedPreferences = getActivity().getSharedPreferences(pref + i, MODE_PRIVATE);
                if(!sharedPreferences.getString(key + i, "").equals("")){
                    text.setText(sharedPreferences.getString(key + i, ""));
                }
        }
        }
    }

    public void gender(String pref, String key, RadioButton one, RadioButton two) {
        for (int i = 0; i < 100; i++) {
            if(this.getArguments().getString("key").equals(i+"")){
                SharedPreferences sharedPreferences = getActivity().getSharedPreferences(pref + i, Context.MODE_PRIVATE);
                if (sharedPreferences.getString(key + i, "").equals("Мужской")) {
                    one.setChecked(true);
                } else if (sharedPreferences.getString(key + i, "").equals("Женский")) {
                    two.setChecked(true);
                }
            }
        }


    }


    public void saveM() {
        binding.buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                save();
            }
        });
        binding.getpetmenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                save();
            }
        });

        binding.btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                save();
            }
        });
    }

    public void save() {

        if (binding.edTextNameED.getText().toString().equals("")) {
            Toast.makeText(getActivity(), "Введите имя Питомца", Toast.LENGTH_SHORT).show();
            binding.edTextNameED.requestFocus();
            setSoftKeyboard();
        } else if (binding.edTextDay.getText().toString().equals("")) {
            Toast.makeText(getActivity(), "Введите день рождения", Toast.LENGTH_SHORT).show();
            binding.edTextDay.requestFocus();
            setSoftKeyboard();
        } else if (binding.edTextMount.getText().toString().equals("")) {
            Toast.makeText(getActivity(), "Введите месяц рождения", Toast.LENGTH_SHORT).show();
            binding.edTextMount.requestFocus();
            setSoftKeyboard();
        } else if (binding.edTextAge.getText().toString().equals("")) {
            Toast.makeText(getActivity(), "Введите год рождения", Toast.LENGTH_SHORT).show();
            binding.edTextAge.requestFocus();
            setSoftKeyboard();
        } else if (binding.spinnerAnimal.getSelectedItem().toString().equals("Выбрать")) {
            Toast.makeText(getActivity(), "Выберите вид Питомца", Toast.LENGTH_SHORT).show();
            binding.spinnerAnimal.requestFocus();
            binding.spinnerAnimal.performClick();
        } else {
            testData(binding.edTextDay, binding.edTextMount, binding.edTextDay);
        }
    }

    private void testData(EditText day, EditText mount, EditText age) {
        SimpleDateFormat datD = new SimpleDateFormat("dd");
        String currentDateandD = datD.format(new Date());
        String data1 = ("" + currentDateandD);
        int currentDay = Integer.parseInt(data1);

        SimpleDateFormat datM = new SimpleDateFormat("MM");
        String currentDateandM = datM.format(new Date());
        String data2 = ("" + currentDateandM);
        int currentMount = Integer.parseInt(data2);

        SimpleDateFormat datY = new SimpleDateFormat("yyyy");
        String currentDateandY = datY.format(new Date());
        String data3 = ("" + currentDateandY);
        int currentAge = Integer.parseInt(data3);

        if (!day.getText().toString().equals("") && !mount.getText().toString().equals("") && !age.getText().toString().equals("")) {
            int dayHappy = Integer.parseInt(day.getText().toString());
            int mountHappy = Integer.parseInt(mount.getText().toString());
            int ageHappy = Integer.parseInt(age.getText().toString());
            if (dayHappy <= 0 || mountHappy <= 0 || ageHappy <= 0) {
                Toast.makeText(getActivity(), "Неверная дата", Toast.LENGTH_SHORT).show();
                day.setText("");
                mount.setText("");
                age.setText("");
                day.requestFocus();
            } else if (dayHappy > 31) {
                Toast.makeText(getActivity(), "Превышает количество дней в месяце", Toast.LENGTH_SHORT).show();
                day.setText("");
                day.requestFocus();
            } else if (dayHappy > currentDay && mountHappy == currentMount && ageHappy == currentAge) {
                Toast.makeText(getActivity(), "Превышает текущий день", Toast.LENGTH_SHORT).show();
                day.setText("");
                day.requestFocus();
            } else if (mountHappy > 12) {
                Toast.makeText(getActivity(), "Превышает количество месяцев в году", Toast.LENGTH_SHORT).show();
                mount.setText("");
                mount.requestFocus();
            } else if (dayHappy >= currentDay && mountHappy > currentMount && ageHappy == currentAge) {
                Toast.makeText(getActivity(), "Превышает текущий месяц", Toast.LENGTH_SHORT).show();
                mount.setText("");
                mount.requestFocus();
            } else if (dayHappy <= currentDay && mountHappy > currentMount && ageHappy == currentAge) {
                Toast.makeText(getActivity(), "Превышает текущий месяц", Toast.LENGTH_SHORT).show();
                mount.setText("");
                mount.requestFocus();
            } else if (ageHappy > currentAge) {
                Toast.makeText(getActivity(), "Превышает текущий год", Toast.LENGTH_SHORT).show();
                age.setText("");
                age.requestFocus();
            } else {
                savePet();
            }
        }
    }

    private void savePet() {
        saveEditText("prefName" + key, "name" + key, binding.edTextNameED);
        saveEditText("prefDay" + key, "day" + key, binding.edTextDay);
        saveEditText("prefMount" + key, "mount" + key, binding.edTextMount);
        saveEditText("prefAge" + key, "age" + key, binding.edTextAge);
        saveGender("prefGender" + key, "gender" + key, gender);
        saveEditText("prefChip" + key, "chip" + key, binding.edTextChip);
        saveSpiner("prefAnimal" + key, "animal" + key, binding.spinnerAnimal);
        saveEditText("prefBreed" + key, "breed" + key, binding.edTextBreed);
        saveEditText("prefColor" + key, "color" + key, binding.edTextColor);
        saveEditText("prefWeight" + key, "weight" + key, binding.edTextWeight);
        saveSpiner("prefKg" + key, "kg" + key, binding.spinnerKg);
        saveEditText("prefHeight" + key, "height" + key, binding.edTextHeight);
        saveEditText("prefBust" + key, "bust" + key, binding.edTextBust);
        saveEditText("prefBack" + key, "back" + key, binding.edTextBack);
        saveEditText("prefGroin" + key, "groin" + key, binding.edTextGroin);
        saveEditText("prefVolume" + key, "volume" + key, binding.edTextVolume);
        saveEditText("prefLength" + key, "length" + key, binding.edTextLength);
        saveEditText("prefWidth" + key, "width" + key, binding.edTextWidth);
        saveEditText("prefDayCast" + key, "dayCast" + key, binding.edTextDayCast);
        saveEditText("prefMountCast" + key, "mountCast" + key, binding.edTextMountCast);
        saveEditText("prefAgeCast" + key, "ageCast" + key, binding.edTextAgeCast);
        saveEditText("prefDayCicle" + key, "dayCicle" + key, binding.edTextDayCicle);
        saveEditText("prefMountCicle" + key, "mountCicle" + key, binding.edTextMountCicle);
        saveEditText("prefAgeCicle" + key, "ageCicle" + key, binding.edTextAgeCicle);
        saveEditText("prefDayCicleExit" + key, "dayCicleExit" + key, binding.edTextDayCicle2);
        saveEditText("prefMountCicleExit" + key, "mountCicleExit" + key, binding.edTextMountCicle2);
        saveEditText("prefAgeCicleExit" + key, "ageCicleExit" + key, binding.edTextAgeCicle2);
        saveEditText("prefNursery" + key, "nursery" + key, binding.edTextNursery);
        saveEditText("prefNote" + key, "note" + key, binding.edTextNote);
    }


    // метод для сохранения выбора радиокнопки ( пола )
    private void saveGender(String pref, String key, String gender) {
        if (!gender.equals("")) {
            SharedPreferences Shared = getActivity().getSharedPreferences(pref, MODE_PRIVATE);
            SharedPreferences.Editor editor = Shared.edit();
            editor.putString(key, gender);
            editor.apply();
        }
    }

    // метод для сохранения выбора спинера, выпающего списка ( вида животного )
    private void saveSpiner(String pref, String key, Spinner spinner) {
        if (!spinner.getSelectedItem().toString().equals("Выбрать")) {
            SharedPreferences Shared = getActivity().getSharedPreferences(pref, MODE_PRIVATE);
            SharedPreferences.Editor editor = Shared.edit();
            editor.putString(key, spinner.getSelectedItem().toString());
            editor.apply();
        }
    }

    // метод для сохранения остальных данных с форм заполнения пользователем
    private void saveEditText(String pref, String key, EditText editText) {

        SharedPreferences Shared = getActivity().getSharedPreferences(pref, MODE_PRIVATE);

        SharedPreferences.Editor editor = Shared.edit();
        editor.putString(key, editText.getText().toString());
        editor.apply();
    }


    // метод для захвата и подмены изображения из галереи
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent) {
        super.onActivityResult(requestCode, resultCode, imageReturnedIntent);
        binding.image.setVisibility(GONE);
        binding.ava.setVisibility(View.VISIBLE);
        Bitmap bitmap = null;
        switch (requestCode) {
            case GALLERY_REQUEST:
                if (resultCode == RESULT_OK) {
                    Uri selectedImage = imageReturnedIntent.getData();
                    try {
                        bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), selectedImage);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    binding.ava2.setImageBitmap(bitmap);
                    try {
                        saveToInternalStorage(bitmap);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
        }
    }

    // метод для сохранеия изображения в локальную память
    private String saveToInternalStorage(Bitmap bitmapImage) throws IOException {
        ContextWrapper cw = new ContextWrapper(getActivity().getApplicationContext());
        // путь /data/data/yourapp/app_data/imageDir
        File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
        // Создаем imageDir
        File mypath = new File(directory, "profile.jpg");

        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(mypath);
            // Используем метод сжатия BitMap объекта для записи в OutputStream
            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            fos.close();
        }
        return directory.getAbsolutePath();
    }

    private void ava() {
        // кнопка загрузить аватарку
        binding.image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                photoPickerIntent.setType("image/*");
                startActivityForResult(photoPickerIntent, GALLERY_REQUEST);
            }
        });

        // кнопка загрузить аватарку
        binding.ava2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                photoPickerIntent.setType("image/*");
                startActivityForResult(photoPickerIntent, GALLERY_REQUEST);
            }
        });

    }

    private void rgGender() {
        // Слушатель выбора радиокнопки
        binding.radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case -1:
                        Toast.makeText(getActivity().getApplicationContext(), "Ничего не выбрано",
                                Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.radioButtonOne:
                        gender = "Мужской";
                        break;
                    case R.id.radioButtonTwo:
                        gender = "Женский";
                        break;
                    default:
                        break;
                }
            }
        });
    }

    private void spAnimal() {
        animalArrayList.add("Выбрать");
        animalArrayList.add("Собака");
        animalArrayList.add("Кошка");
        animalArrayList.add("Попугай");
        animalArrayList.add("Крыса");
        animalArrayList.add("Шиншила");
        animalArrayList.add("Хомяк");
        animalArrayList.add("Черепаха");
        loadSpAnimal();
        animalArrayList.add("Другое");
        animalArrayAdapter = new ArrayAdapter<String>(getActivity(), R.layout.spinner_layout, R.id.text_item, animalArrayList);
        binding.spinnerAnimal.setAdapter(animalArrayAdapter);
        binding.spinnerAnimal.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = parent.getItemAtPosition(position).toString();
                if (selectedItem.equals("Другое")) {
                    spinerAnimaltest();
                }
            }

            private void spinerAnimaltest() {
                LayoutInflater li = LayoutInflater.from(getActivity());
                View promptsView = li.inflate(R.layout.spinner_animal_layout, null);
                AlertDialog.Builder mDialogBuilder = new AlertDialog.Builder(getActivity());
                mDialogBuilder.setView(promptsView);
                final EditText userInput = (EditText) promptsView.findViewById(R.id.set_text);
                mDialogBuilder
                        .setCancelable(false)
                        .setPositiveButton("OK",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        animalText = userInput.getText().toString();
                                        saveMyAnimal();
                                        onAdd();
                                        int count = animalArrayList.size();
                                        binding.spinnerAnimal.setSelection(count - 1);
                                    }

                                    // метод сохранения новых видов питомцев
                                    public void saveMyAnimal() {
                                        for (int i = 1; i < 100; i++) {

                                            SharedPreferences sharedPreferences1 = getActivity().getSharedPreferences("prefMyAnimal" + i, MODE_PRIVATE);
                                            if (sharedPreferences1.getString("myAnimal" + i, "").equals("")) {
                                                SharedPreferences shared = getActivity().getSharedPreferences("prefMyAnimal" + i, MODE_PRIVATE);
                                                SharedPreferences.Editor editor = shared.edit();
                                                editor.putString("myAnimal" + i, animalText);
                                                editor.apply();
                                                break;
                                            }

                                        }
                                    }

                                    private void onAdd() {
                                        animalArrayList.add(animalText + "");
                                        binding.spinnerAnimal.setAdapter(animalArrayAdapter); // наполняем спиннер данными из адаптера
                                    }

                                })
                        .setNegativeButton("Отмена",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                    }
                                });
                AlertDialog alertDialog = mDialogBuilder.create();
                alertDialog.show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    // Метод проверки и добавление новых питомцев из сохраненки
    private void loadSpAnimal() {
        for (int i = 1; i < 100; i++) {
            SharedPreferences sharedPreferences = getActivity().getSharedPreferences("prefMyAnimal" + i, MODE_PRIVATE);
            if (!sharedPreferences.getString("myAnimal" + i, "").equals("")) {
                animalArrayList.add(sharedPreferences.getString("myAnimal" + i, ""));
            }
        }
    }

    public void listener() {
        binding.headerTextParams.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnParam();
            }
        });

        binding.btnShowParams.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnParam();
            }
        });

        binding.btnHideParams.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnParam();
            }
        });

        binding.headerTextInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnInfo();
            }
        });

        binding.btnShowInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnInfo();
            }
        });

        binding.btnHideInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnInfo();
            }
        });

    }

    // кнопка по нажатию на текст, скрыть или показать Иную информацию из onClick
    public void btnInfo() {
        if (binding.btnShowInfo.getVisibility() == View.VISIBLE) {
            binding.btnShowInfo.setVisibility(View.GONE);
            binding.btnHideInfo.setVisibility(View.VISIBLE);
            showInfo();
        } else {
            binding.btnShowInfo.setVisibility(View.VISIBLE);
            binding.btnHideInfo.setVisibility(View.GONE);
            hideInfo();
        }
    }

    // Метод показать иную информацию
    private void showInfo() {
        createMetod.showInfo(binding.btnHideInfo,
                binding.textCast, binding.textCicl, binding.textNursery, binding.textNote,
                binding.edTextDayCast, binding.edTextMountCast, binding.edTextAgeCast,
                binding.edTextDayCicle, binding.edTextMountCicle, binding.edTextAgeCicle,
                binding.edTextDayCicle2, binding.edTextMountCicle2, binding.edTextAgeCicle2,
                binding.edTextNursery, binding.edTextNote, binding.tochDayCast, binding.tochMountCast,
                binding.tochAgeCast, binding.tochDayCicle, binding.tochMountCicle,
                binding.tochAgeCicle, binding.tochDayCicle2, binding.tochMountCicle2, binding.tochAgeCicle2,
                binding.layoutDataCast, binding.layoutDataCicle, binding.layoutDataCicle2);
    }

    // кнопка по нажатию на текст, скрыть или показать Параметры onClick
    public void btnParam() {
        if (binding.btnShowParams.getVisibility() == View.VISIBLE) {
            binding.btnShowParams.setVisibility(View.GONE);
            binding.btnHideParams.setVisibility(View.VISIBLE);
            showParams();
        } else {
            binding.btnShowParams.setVisibility(View.VISIBLE);
            binding.btnHideParams.setVisibility(View.GONE);
            hideParam();
        }
    }

    // метод показать параметры
    private void showParams() {
        createMetod.showParam(binding.btnHideParams,
                binding.spinnerKg,
                binding.textWeight, binding.textHeight, binding.textBust, binding.textBack, binding.textGroin, binding.textGroin2, binding.textVolume, binding.textLength, binding.textWidth,
                binding.edTextWeight, binding.edTextHeight, binding.edTextBust, binding.edTextBack, binding.edTextGroin, binding.edTextVolume, binding.edTextLength, binding.edTextWidth,
                binding.smHeight, binding.smBust, binding.smBack, binding.smGroin, binding.smVolume, binding.smLength, binding.smWidth,
                binding.layoutDataGender, binding.layoutDataGenderText, binding.layoutWeightHeight, binding.layoutWeightHeightText, binding.layoutBustBack,
                binding.layoutBustBackText, binding.layoutNeckGroin, binding.layoutNeckGroinText, binding.layoutLengthWidth, binding.layoutLengthWidthText,
                binding.layoutWeight, binding.layoutHeight, binding.layoutBust, binding.layoutBack, binding.layoutGroin, binding.layoutVolume, binding.layoutLength, binding.layoutWidth);
    }

    // метод скрыть иную информацию из класса Креат работат по умолчанию при загрузке
    private void hideInfo() {
        createMetod.hideInfo(binding.btnHideInfo,
                binding.textCast, binding.textCicl, binding.textNursery, binding.textNote,
                binding.edTextDayCast, binding.edTextMountCast, binding.edTextAgeCast,
                binding.edTextDayCicle, binding.edTextMountCicle, binding.edTextAgeCicle,
                binding.edTextDayCicle2, binding.edTextMountCicle2, binding.edTextAgeCicle2,
                binding.edTextNursery, binding.edTextNote, binding.tochDayCast, binding.tochMountCast,
                binding.tochAgeCast, binding.tochDayCicle, binding.tochMountCicle,
                binding.tochAgeCicle, binding.tochDayCicle2, binding.tochMountCicle2, binding.tochAgeCicle2,
                binding.layoutDataCast, binding.layoutDataCicle, binding.layoutDataCicle2
        );
    }

    // метод скрыть параметры из класса Креат работат по умолчанию при загрузке
    private void hideParam() {
        createMetod.hideParam(binding.btnHideParams,
                binding.spinnerKg,
                binding.textWeight, binding.textHeight, binding.textBust, binding.textBack, binding.textGroin, binding.textGroin2, binding.textVolume, binding.textLength, binding.textWidth,
                binding.edTextWeight, binding.edTextHeight, binding.edTextBust, binding.edTextBack, binding.edTextGroin, binding.edTextVolume, binding.edTextLength, binding.edTextWidth,
                binding.smHeight, binding.smBust, binding.smBack, binding.smGroin, binding.smVolume, binding.smLength, binding.smWidth,
                binding.layoutWeightHeight, binding.layoutWeightHeightText, binding.layoutBustBack,
                binding.layoutBustBackText, binding.layoutNeckGroin, binding.layoutNeckGroinText, binding.layoutLengthWidth, binding.layoutLengthWidthText,
                binding.layoutWeight, binding.layoutHeight, binding.layoutBust, binding.layoutBack, binding.layoutGroin, binding.layoutVolume, binding.layoutLength, binding.layoutWidth);
    }

    public void editTextHide() {
        enter(binding.edTextChip);
        enter(binding.edTextColor);
        enter(binding.edTextWidth);
    }

    // При нажатии на Enter на кливиатуре убираем фокус и прячем клавиатуру
    void enter(EditText editText) {
        editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    editText.clearFocus();
                    setSoftKeyboard();
                    return true;
                }
                return false;
            }
        });
    }

    private void setSoftKeyboard() {
        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Activity.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
    }

    private void jump() {  // автоматический переход Дата рождения
        createMetod.dataAvtomat(binding.edTextDay, binding.edTextMount, binding.edTextAge, binding.edTextChip);
        // автоматический переход по параметрам
        createMetod.paramAvtomat(binding.edTextWeight, binding.edTextHeight, binding.edTextBust, binding.edTextBack, binding.edTextGroin, binding.edTextVolume, binding.edTextLength, binding.edTextWidth);
        // автоматический переход Дата кастрации
        createMetod.dataAvtomat(binding.edTextDayCast, binding.edTextMountCast, binding.edTextAgeCast, binding.edTextDayCicle);
        // автоматический переход Дата начало цикла
        createMetod.dataAvtomat(binding.edTextDayCicle, binding.edTextMountCicle, binding.edTextAgeCicle, binding.edTextDayCicle2);
        // аатоматический переход Дата конца цикла
        createMetod.dataAvtomat(binding.edTextDayCicle2, binding.edTextMountCicle2, binding.edTextAgeCicle2, binding.edTextNursery);
    }
}